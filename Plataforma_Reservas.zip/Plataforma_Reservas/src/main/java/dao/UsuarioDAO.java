
package dao;

import java.sql.*;
import modelo.Usuario;
import conexion.ConexionBD;

public class UsuarioDAO {

 public Usuario obtenerUsuarioPorNombre(String nombreUsuario) {
        Usuario usuario = null;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.conectar();
            String sql = "SELECT * FROM usuario WHERE nombre = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nombreUsuario);
            rs = stmt.executeQuery();

            if (rs.next()) {
                usuario = new Usuario(
                    rs.getInt("id_usuario"),
                    rs.getString("nombre"),
                    rs.getString("contraseña")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return usuario;
    }
        
 public boolean registrarUsuario(Usuario usuario) {
    Connection conn = null;
    PreparedStatement stmt = null;
    boolean exito = false;

    try {
        conn = ConexionBD.conectar();
        String sql = "INSERT INTO usuario(nombre, email, contraseña) VALUES (?, ?, ?)";
        stmt = conn.prepareStatement(sql);
        stmt.setString(1, usuario.getNombreUsuario());
        stmt.setString(2, usuario.getCorreo());
        stmt.setString(3, usuario.getContrasena());

        int filas = stmt.executeUpdate();
        exito = filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return exito;
}
}
