package component;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import modelo.Sala;

public class DialogConfigurarSala extends JDialog {

    private Consumer<Sala> callback;
    private JPanel panelImagen;
    private JButton btnComponentes;
    private JPanel panelLateralComponentes;
    private JSpinner spinnerCapacidad;
    private JTextField campoNombre;
    private JButton btnPrev, btnNext;
    private CardLayout imagenesLayout;
    private List<ImageIcon> imagenes = new ArrayList<>();
    private int idxActual = 0;

    public DialogConfigurarSala(JFrame parent, Consumer<Sala> callback) {
        super(parent, "Configurar Sala", true);
        this.callback = callback;

        setSize(new Dimension(250, 420));
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        // Panel principal
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelPrincipal.setBackground(Color.WHITE);

        // Parte superior (Añadir imagen)
        JPanel wrapper = new JPanel(new BorderLayout());
        //wrapper.setPreferredSize(new Dimension(500, 600));
        wrapper.setBackground(new Color(230, 230, 230));
        wrapper.setCursor(new Cursor(Cursor.HAND_CURSOR));

        imagenesLayout = new CardLayout();
        panelImagen = new JPanel(imagenesLayout);
        wrapper.add(panelImagen, BorderLayout.CENTER);

        // Texto inicial de "Añadir imagen" con el símbolo "+"
        JLabel lblAñadirImagen = new JLabel("Añadir imagen +");
        lblAñadirImagen.setHorizontalAlignment(SwingConstants.CENTER);
        lblAñadirImagen.setFont(new Font("Arial", Font.PLAIN, 14));
        wrapper.add(lblAñadirImagen, BorderLayout.CENTER);

        // Botones de navegación
        btnPrev = new JButton("<");
        btnNext = new JButton(">");
        btnPrev.setFocusable(false);
        btnNext.setFocusable(false);
        btnPrev.setVisible(false); // Inicialmente ocultos
        btnNext.setVisible(false); // Inicialmente ocultos
        wrapper.add(btnPrev, BorderLayout.WEST);
        wrapper.add(btnNext, BorderLayout.EAST);

        // Listener para abrir el chooser (sobre el wrapper, no sobre flechas)
        wrapper.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.getX() > btnPrev.getWidth() && e.getX() < wrapper.getWidth() - btnNext.getWidth()) {
                    JFileChooser chooser = new JFileChooser();
                    chooser.setMultiSelectionEnabled(true);
                    if (chooser.showOpenDialog(DialogConfigurarSala.this) == JFileChooser.APPROVE_OPTION) {
                        File[] files = chooser.getSelectedFiles();
                        for (File file : files) {
                            ImageIcon ico = new ImageIcon(
                                new ImageIcon(file.getAbsolutePath())
                                  .getImage()
                                  .getScaledInstance(wrapper.getWidth() - 40, wrapper.getHeight(), Image.SCALE_SMOOTH)
                            );
                            imagenes.add(ico);
                            JLabel lbl = new JLabel(ico);
                            panelImagen.add(lbl, String.valueOf(imagenes.size() - 1));
                        }

                        // Mostrar la imagen añadida
                        idxActual = imagenes.size() - files.length; // Ajustar el índice
                        imagenesLayout.show(panelImagen, String.valueOf(idxActual));

                        // Revalidar y repintar todo el contenedor
                        panelImagen.revalidate();
                        panelImagen.repaint();
                        wrapper.revalidate();
                        wrapper.repaint();

                        // Mostrar u ocultar los botones de navegación
                        btnPrev.setVisible(imagenes.size() > 1);
                        btnNext.setVisible(imagenes.size() > 1);

                        // Cambiar el texto de "Añadir imagen" por una imagen
                        lblAñadirImagen.setVisible(false);
                    }
                }
            }
        });

        // Listeners de flechas
        btnPrev.addActionListener(e -> {
            if (imagenes.isEmpty()) return;
            idxActual = (idxActual - 1 + imagenes.size()) % imagenes.size();
            imagenesLayout.show(panelImagen, String.valueOf(idxActual));
        });
        btnNext.addActionListener(e -> {
            if (imagenes.isEmpty()) return;
            idxActual = (idxActual + 1) % imagenes.size();
            imagenesLayout.show(panelImagen, String.valueOf(idxActual));
        });

        panelPrincipal.add(wrapper, BorderLayout.NORTH);

        // Parte inferior
        JPanel panelCampos = new JPanel();
        panelCampos.setLayout(new BoxLayout(panelCampos, BoxLayout.Y_AXIS));
        panelCampos.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panelCampos.setBackground(Color.WHITE);

        campoNombre = new JTextField();
        campoNombre.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        campoNombre.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblCapacidad = new JLabel("Capacidad:");
        lblCapacidad.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnComponentes = new JButton("Componentes");
        btnComponentes.setAlignmentX(Component.LEFT_ALIGNMENT);

        spinnerCapacidad = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
        spinnerCapacidad.setMaximumSize(new Dimension(100, 30));
        spinnerCapacidad.setAlignmentX(Component.LEFT_ALIGNMENT);

        panelCampos.add(lblNombre);
        panelCampos.add(Box.createRigidArea(new Dimension(0, 5)));
        panelCampos.add(campoNombre);

        panelCampos.add(Box.createRigidArea(new Dimension(0, 15)));
        panelCampos.add(lblCapacidad);
        panelCampos.add(spinnerCapacidad);

        panelCampos.add(Box.createRigidArea(new Dimension(0, 15)));
        panelCampos.add(btnComponentes);

        // Panel lateral oculto
        panelLateralComponentes = new JPanel();
        panelLateralComponentes.setPreferredSize(new Dimension(200, 0));
        panelLateralComponentes.setBackground(new Color(245, 245, 245));
        panelLateralComponentes.setVisible(false); // empieza oculto

        // Acción del botón "Componentes"
        btnComponentes.addActionListener(e -> {
            panelLateralComponentes.setVisible(!panelLateralComponentes.isVisible());
            pack();
        });

        panelPrincipal.add(wrapper, BorderLayout.NORTH);
        panelPrincipal.add(panelCampos, BorderLayout.CENTER);
        add(panelPrincipal, BorderLayout.CENTER);
        add(panelLateralComponentes, BorderLayout.EAST);

        JButton btnGuardar = new JButton("Guardar Sala");
        btnGuardar.addActionListener(e -> guardarSala());
        panelCampos.add(Box.createRigidArea(new Dimension(0, 15)));
        panelCampos.add(btnGuardar);
    }

    private void guardarSala() {
        String nombre = campoNombre.getText().trim();
        int capacidad = (int) spinnerCapacidad.getValue();

        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (imagenes.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe añadir al menos una imagen.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Crea el objeto Sala
        Sala nuevaSala = new Sala(nombre, capacidad, imagenes);

        // Llama al callback para pasárselo al que abrió el diálogo
        callback.accept(nuevaSala);

        // Cierra la ventana
        dispose();
    }
}
