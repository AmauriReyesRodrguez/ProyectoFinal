package component;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.Locale;

public class Panel_Calendario extends JPanel {

    private JPanel panelDias;
    private JLabel lblMes;
    private LocalDate fechaActual;
    private JPanel panelDerecho;
    private JButton btnAgregarReserva;

    public Panel_Calendario() {
        fechaActual = LocalDate.now();
        initComponents();
        mostrarCalendario(fechaActual);
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 240, 240));

        // Encabezado con gradiente y título centrado
        JPanel encabezado = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(85, 170, 255), getWidth(), getHeight(), new Color(0, 102, 204));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                super.paintComponent(g);
            }
        };
        encabezado.setOpaque(false);
        encabezado.setLayout(new BorderLayout());
        encabezado.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titulo = new JLabel("📅 Calendario");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);

        encabezado.add(titulo, BorderLayout.CENTER);
        add(encabezado, BorderLayout.NORTH);

        // Contenedor redondeado
        JPanel panelContenedor = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        panelContenedor.setBorder(new EmptyBorder(15, 15, 15, 15));
        panelContenedor.setOpaque(false);

        // Panel izquierdo (calendario)
        JPanel panelIzquierdo = new JPanel(new BorderLayout());
        panelIzquierdo.setOpaque(false);

        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelSuperior.setOpaque(false);
        JButton btnAnterior = new JButton("<");
        JButton btnSiguiente = new JButton(">");
        lblMes = new JLabel();
        lblMes.setFont(new Font("Segoe UI", Font.BOLD, 20));

        btnAnterior.addActionListener(e -> cambiarMes(-1));
        btnSiguiente.addActionListener(e -> cambiarMes(1));

        panelSuperior.add(btnAnterior);
        panelSuperior.add(lblMes);
        panelSuperior.add(btnSiguiente);
        panelIzquierdo.add(panelSuperior, BorderLayout.NORTH);

        panelDias = new JPanel(new GridLayout(0, 7, 8, 8));
        panelDias.setOpaque(false);
        panelIzquierdo.add(panelDias, BorderLayout.CENTER);

        panelContenedor.add(panelIzquierdo, BorderLayout.CENTER);

        // Panel derecho (navegador de reservas)
        panelDerecho = new JPanel(new BorderLayout());
        panelDerecho.setPreferredSize(new Dimension(220, 0));
        panelDerecho.setBackground(new Color(240, 240, 240));

        JLabel lblNavegador = new JLabel("Navegador de reservas", SwingConstants.CENTER);
        lblNavegador.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblNavegador.setBorder(new EmptyBorder(20, 10, 20, 10));

        btnAgregarReserva = new JButton("➕ Añadir reserva");
        btnAgregarReserva.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnAgregarReserva.setFocusPainted(false);
        btnAgregarReserva.setVisible(false);
        btnAgregarReserva.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Aquí se abrirá un diálogo para añadir la reserva.");
        });

        panelDerecho.add(lblNavegador, BorderLayout.NORTH);
        panelDerecho.add(btnAgregarReserva, BorderLayout.SOUTH);

        panelContenedor.add(panelDerecho, BorderLayout.EAST);

        add(panelContenedor, BorderLayout.CENTER);
    }

    private void mostrarCalendario(LocalDate fecha) {
        panelDias.removeAll();

        lblMes.setText(fecha.getMonth().getDisplayName(TextStyle.FULL, new Locale("es", "ES")).toUpperCase() + " " + fecha.getYear());

        // Días de la semana
        String[] diasSemana = {"L", "M", "X", "J", "V", "S", "D"};
        for (String dia : diasSemana) {
            JLabel lblDia = new JLabel(dia, SwingConstants.CENTER);
            lblDia.setFont(new Font("Segoe UI", Font.BOLD, 14));
            panelDias.add(lblDia);
        }

        LocalDate primerDia = fecha.withDayOfMonth(1);
        int diaSemana = primerDia.getDayOfWeek().getValue();
        if (diaSemana == 7) diaSemana = 0;

        int diasDelMes = fecha.lengthOfMonth();

        for (int i = 1; i < diaSemana; i++) {
            panelDias.add(new JLabel(""));
        }

        for (int dia = 1; dia <= diasDelMes; dia++) {
            JButton btnDia = new JButton(String.valueOf(dia));
            btnDia.setFocusPainted(false);
            btnDia.setContentAreaFilled(false);
            btnDia.setBorderPainted(false);
            btnDia.setForeground(Color.BLACK);
            btnDia.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btnDia.setUI(new RoundedButtonUI());
            btnDia.setBackground(Color.WHITE);

            btnDia.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseEntered(MouseEvent e) {
        btnDia.setBackground(new Color(200, 220, 255));
        btnDia.setContentAreaFilled(true);
        btnDia.repaint();
    }

    @Override
    public void mouseExited(MouseEvent e) {
        btnDia.setContentAreaFilled(false);
        btnDia.repaint();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        btnAgregarReserva.setVisible(true); // solo mostrar al hacer clic
    }

    @Override
    public void mousePressed(MouseEvent e) {
        btnDia.setBackground(new Color(130, 170, 255));
        btnDia.setContentAreaFilled(true);
        btnDia.repaint();
    }
});


            panelDias.add(btnDia);
        }

        panelDias.revalidate();
        panelDias.repaint();
    }

    private void cambiarMes(int cambio) {
        fechaActual = fechaActual.plusMonths(cambio);
        mostrarCalendario(fechaActual);
        btnAgregarReserva.setVisible(false); // Ocultar botón al cambiar de mes
    }
}
