/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package component;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;

public class PanelLateral extends javax.swing.JPanel {

    private PanelContenido panelContenido;

    public PanelLateral() {
    }

    
    public PanelLateral(PanelContenido panelContenido) {
        initComponents();
        this.panelContenido = panelContenido;
    }

       @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Convierte a Graphics2D
        Graphics2D g2d = (Graphics2D) g;

        // Crea un degradado vertical (de arriba a abajo)
        GradientPaint gradient = new GradientPaint(
                0, 0, new Color(224, 0, 0),       // Color inicial (arriba)
                0, getHeight(), new Color(138, 0, 0) // Color final (abajo)
        );

        // Si prefieres un degradado horizontal (de izquierda a derecha), usa esto:
        // GradientPaint gradient = new GradientPaint(
        //     0, 0, new Color(255, 81, 81),
        //     getWidth(), 0, new Color(255, 150, 150)
        // );

        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
