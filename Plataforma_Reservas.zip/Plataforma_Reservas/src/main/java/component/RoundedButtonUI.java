/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package component;

import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import javax.swing.*;

public class RoundedButtonUI extends BasicButtonUI {
    @Override
    public void paint(Graphics g, JComponent c) {
        JButton b = (JButton) c;
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (b.isContentAreaFilled()) {
            g2.setColor(b.getBackground());
            int size = Math.min(b.getWidth(), b.getHeight());
            g2.fillOval(0, 0, size, size);
        }

        FontMetrics fm = g2.getFontMetrics();
        Rectangle r = new Rectangle(b.getSize());
        String text = b.getText();
        int textWidth = fm.stringWidth(text);
        int textHeight = fm.getAscent();

        g2.setColor(b.getForeground());
        g2.drawString(text, (r.width - textWidth) / 2, (r.height + textHeight) / 2 - 2);

        g2.dispose();
    }
}
