package component;

import javax.swing.*;
import java.awt.*;
import modelo.Sala;

public class PanelSalaItem extends JPanel {
    public PanelSalaItem(Sala sala) {
        setPreferredSize(new Dimension(250, 250));
        setBackground(new Color(225, 226, 227));
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JLabel lblNombre = new JLabel("<html><center>" + sala.getNombre() + "</center></html>", SwingConstants.CENTER);
        JLabel lblCapacidad = new JLabel("Capacidad: " + sala.getCapacidad(), SwingConstants.CENTER);

        add(lblNombre, BorderLayout.CENTER);
        add(lblCapacidad, BorderLayout.SOUTH);
    }
}
