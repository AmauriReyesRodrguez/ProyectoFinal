
package vista;

import com.formdev.flatlaf.FlatLightLaf; // O usa FlatDarkLaf para el tema oscuro
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import component.PanelContenido;
import component.PanelLateral;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;



public class MenuPrincipal extends javax.swing.JFrame {

   
    

    public MenuPrincipal() {
        
        initComponents();
 
        
    }

    
    
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelLateral = new component.PanelLateral();
        labelTitulo = new javax.swing.JLabel();
        labelGeneral = new javax.swing.JLabel();
        botonPrincipal = new javax.swing.JButton();
        botonCalendario = new javax.swing.JButton();
        botonsala = new javax.swing.JButton();
        panelLateral.add(javax.swing.Box.createVerticalStrut(14));
        saparador = new javax.swing.JSeparator();
        labelMas = new javax.swing.JLabel();
        botonBF = new javax.swing.JButton();
        botonConfi = new javax.swing.JButton();
        panelContenido = new component.PanelContenido();
        panelPrincipal = new component.PanelPrincipal();
        jLabel5 = new javax.swing.JLabel();
        panelSala = new component.PanelSala();
        jLabel1 = new javax.swing.JLabel();
        panelInfo = new component.PanelInfo();
        jLabel3 = new javax.swing.JLabel();
        panelConfiguracion = new component.PanelConfiguracion();
        jLabel4 = new javax.swing.JLabel();
        panelCalendario = new component.PanelCalendario();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1080, 500));

        panelLateral.setBackground(new java.awt.Color(0, 0, 0,100)
        );
        panelLateral.setLayout(new javax.swing.BoxLayout(panelLateral, javax.swing.BoxLayout.PAGE_AXIS));

        labelTitulo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        labelTitulo.setForeground(new java.awt.Color(255, 255, 255));
        labelTitulo.setText("Brook Jaaf");
        labelTitulo.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelLateral.add(labelTitulo);
        panelLateral.add(javax.swing.Box.createVerticalStrut(18));

        labelGeneral.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelGeneral.setForeground(new java.awt.Color(255, 255, 255));
        labelGeneral.setText("General");
        labelGeneral.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 2, 10));
        panelLateral.add(labelGeneral);
        panelLateral.add(javax.swing.Box.createVerticalStrut(10));

        botonPrincipal.setBackground(new java.awt.Color(0, 0, 0,0));
        botonPrincipal.setForeground(java.awt.Color.WHITE); // Mantén el color del texto blanco
        botonPrincipal.setBorder(null);
        botonPrincipal.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        botonPrincipal.setText("🏠  Principal");
        botonPrincipal.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 90));
        botonPrincipal.setFocusPainted(false);
        botonPrincipal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPrincipalActionPerformed(evt);
            }
        });
        botonPrincipal.addMouseListener(new java.awt.event.MouseAdapter() {
            java.awt.Color originalColor = botonPrincipal.getBackground();
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonPrincipal.setBackground(new java.awt.Color(0, 0, 0,100));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonPrincipal.setBackground(originalColor);
            }
        });
        panelLateral.add(botonPrincipal);
        panelLateral.add(javax.swing.Box.createVerticalStrut(2));

        botonCalendario.setBackground(new java.awt.Color(0, 0, 0,0));
        botonCalendario.setForeground(java.awt.Color.WHITE); // Mantén el color del texto blanco
        botonCalendario.setBorder(null);
        botonCalendario.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        botonCalendario.setText("📅  Calendario");
        botonCalendario.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 77));
        botonCalendario.setFocusPainted(false);
        botonCalendario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCalendarioActionPerformed(evt);
            }
        });
        botonCalendario.addMouseListener(new java.awt.event.MouseAdapter() {
            java.awt.Color originalColor = botonCalendario.getBackground();
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonCalendario.setBackground(new java.awt.Color(0, 0, 0,100));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonCalendario.setBackground(originalColor);
            }
        });
        panelLateral.add(botonCalendario);
        panelLateral.add(javax.swing.Box.createVerticalStrut(2));

        botonsala.setBackground(new java.awt.Color(0, 0, 0,0));
        botonsala.setForeground(java.awt.Color.WHITE); // Mantén el color del texto blanco
        botonsala.setBorder(null);
        botonsala.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        botonsala.setText("🎭  Salas");
        botonsala.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 111));
        botonsala.setFocusPainted(false);
        botonsala.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonsalaActionPerformed(evt);
            }
        });
        botonsala.addMouseListener(new java.awt.event.MouseAdapter() {
            java.awt.Color originalColor = botonsala.getBackground();
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonsala.setBackground(new java.awt.Color(0, 0, 0,100));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonsala.setBackground(originalColor);
            }
        });
        panelLateral.add(botonsala);
        panelLateral.add(javax.swing.Box.createVerticalStrut(185));

        saparador.setOrientation(javax.swing.SwingConstants.HORIZONTAL); // Asegúrate de que sea horizontal
        saparador.setPreferredSize(new java.awt.Dimension(Integer.MAX_VALUE, 1)); // Ancho máximo, alto de 1 píxel
        saparador.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 1)); // Ancho máximo, alto máximo de 1 píxel
        saparador.setBackground(new java.awt.Color(249, 249, 249));
        saparador.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        saparador.setPreferredSize(new java.awt.Dimension(10, 10));
        saparador.setVerifyInputWhenFocusTarget(false);
        panelLateral.add(saparador);
        panelLateral.add(javax.swing.Box.createVerticalStrut(17));

        labelMas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelMas.setForeground(new java.awt.Color(255, 255, 255));
        labelMas.setText("Más");
        labelMas.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 10, 2, 10));
        panelLateral.add(labelMas);
        panelLateral.add(javax.swing.Box.createVerticalStrut(10));

        botonBF.setBackground(new java.awt.Color(0, 0, 0,0));
        botonBF.setForeground(java.awt.Color.WHITE); // Mantén el color del texto blanco
        botonBF.setBorder(null);
        botonBF.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        botonBF.setText("📅  Brook Jaaf");
        botonBF.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 79));
        botonBF.setFocusPainted(false);
        botonBF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBFActionPerformed(evt);
            }
        });
        botonBF.addMouseListener(new java.awt.event.MouseAdapter() {
            java.awt.Color originalColor = botonBF.getBackground();
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonBF.setBackground(new java.awt.Color(0, 0, 0,100));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonBF.setBackground(originalColor);
            }
        });
        panelLateral.add(botonBF);
        panelLateral.add(javax.swing.Box.createVerticalStrut(2));

        botonConfi.setBackground(new java.awt.Color(0, 0, 0,0));
        botonConfi.setForeground(java.awt.Color.WHITE); // Mantén el color del texto blanco
        botonConfi.setBorder(null);
        botonConfi.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        botonConfi.setText("⚙  Configuración");
        botonConfi.setAutoscrolls(true);
        botonConfi.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 56));
        botonConfi.setFocusPainted(false);
        botonConfi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonConfiActionPerformed(evt);
            }
        });
        botonConfi.addMouseListener(new java.awt.event.MouseAdapter() {
            java.awt.Color originalColor = botonConfi.getBackground();
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonConfi.setBackground(new java.awt.Color(0, 0, 0,100));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonConfi.setBackground(originalColor);
            }
        });
        panelLateral.add(botonConfi);

        getContentPane().add(panelLateral, java.awt.BorderLayout.WEST);

        panelContenido.setBackground(new java.awt.Color(204, 204, 204));
        panelContenido.setLayout(new java.awt.CardLayout());

        panelPrincipal.setBackground(new java.awt.Color(204, 204, 204));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Principal");

        javax.swing.GroupLayout panelPrincipalLayout = new javax.swing.GroupLayout(panelPrincipal);
        panelPrincipal.setLayout(panelPrincipalLayout);
        panelPrincipalLayout.setHorizontalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(124, Short.MAX_VALUE))
        );
        panelPrincipalLayout.setVerticalGroup(
            panelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPrincipalLayout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(124, Short.MAX_VALUE))
        );

        panelContenido.add(panelPrincipal, "card2");

        panelSala.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Salas");

        javax.swing.GroupLayout panelSalaLayout = new javax.swing.GroupLayout(panelSala);
        panelSala.setLayout(panelSalaLayout);
        panelSalaLayout.setHorizontalGroup(
            panelSalaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSalaLayout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(250, Short.MAX_VALUE))
        );
        panelSalaLayout.setVerticalGroup(
            panelSalaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSalaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(366, Short.MAX_VALUE))
        );

        panelContenido.add(panelSala, "card3");

        panelInfo.setBackground(new java.awt.Color(204, 204, 204));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Información");

        javax.swing.GroupLayout panelInfoLayout = new javax.swing.GroupLayout(panelInfo);
        panelInfo.setLayout(panelInfoLayout);
        panelInfoLayout.setHorizontalGroup(
            panelInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelInfoLayout.createSequentialGroup()
                .addContainerGap(82, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(74, 74, 74))
        );
        panelInfoLayout.setVerticalGroup(
            panelInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelInfoLayout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(141, Short.MAX_VALUE))
        );

        panelContenido.add(panelInfo, "card4");

        panelConfiguracion.setBackground(new java.awt.Color(204, 204, 204));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Configuración");

        javax.swing.GroupLayout panelConfiguracionLayout = new javax.swing.GroupLayout(panelConfiguracion);
        panelConfiguracion.setLayout(panelConfiguracionLayout);
        panelConfiguracionLayout.setHorizontalGroup(
            panelConfiguracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelConfiguracionLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );
        panelConfiguracionLayout.setVerticalGroup(
            panelConfiguracionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelConfiguracionLayout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(146, Short.MAX_VALUE))
        );

        panelContenido.add(panelConfiguracion, "card5");

        panelCalendario.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Calendario");

        javax.swing.GroupLayout panelCalendarioLayout = new javax.swing.GroupLayout(panelCalendario);
        panelCalendario.setLayout(panelCalendarioLayout);
        panelCalendarioLayout.setHorizontalGroup(
            panelCalendarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCalendarioLayout.createSequentialGroup()
                .addContainerGap(92, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84))
        );
        panelCalendarioLayout.setVerticalGroup(
            panelCalendarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCalendarioLayout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(146, Short.MAX_VALUE))
        );

        panelContenido.add(panelCalendario, "card6");

        getContentPane().add(panelContenido, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonConfiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonConfiActionPerformed
        panelContenido.mostrar("card5");
    }//GEN-LAST:event_botonConfiActionPerformed

    private void botonsalaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonsalaActionPerformed
                panelContenido.mostrar("card3");

    }//GEN-LAST:event_botonsalaActionPerformed

    private void botonCalendarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCalendarioActionPerformed
        panelContenido.mostrar("card6");

    }//GEN-LAST:event_botonCalendarioActionPerformed

    private void botonBFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBFActionPerformed
                panelContenido.mostrar("card4");

    }//GEN-LAST:event_botonBFActionPerformed

    private void botonPrincipalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPrincipalActionPerformed

        panelContenido.mostrar("card2");
    }//GEN-LAST:event_botonPrincipalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
        UIManager.setLookAndFeel(new FlatLightLaf()); // Usa FlatLightLaf para el tema claro
        // O si prefieres el tema oscuro:
        // UIManager.setLookAndFeel(new com.formdev.flatlaf.FlatDarkLaf());


        
    } catch (UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(MenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }

    /* Create and display the form */
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new MenuPrincipal().setVisible(true);
        }
    });
}

       
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonBF;
    private javax.swing.JButton botonCalendario;
    private javax.swing.JButton botonConfi;
    private javax.swing.JButton botonPrincipal;
    private javax.swing.JButton botonsala;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel labelGeneral;
    private javax.swing.JLabel labelMas;
    private javax.swing.JLabel labelTitulo;
    private component.PanelCalendario panelCalendario;
    private component.PanelConfiguracion panelConfiguracion;
    private component.PanelContenido panelContenido;
    private component.PanelInfo panelInfo;
    private component.PanelLateral panelLateral;
    private component.PanelPrincipal panelPrincipal;
    private component.PanelSala panelSala;
    private javax.swing.JSeparator saparador;
    // End of variables declaration//GEN-END:variables
}
