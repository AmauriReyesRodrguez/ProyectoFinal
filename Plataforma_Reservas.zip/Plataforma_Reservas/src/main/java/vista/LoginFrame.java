/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import javax.swing.*;
import servicio.LoginService;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {

    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JButton botonLogin;
    private JButton botonRegistro;

    private LoginService loginService;

    public LoginFrame() {
        super("Inicio de Sesión");
        loginService = new LoginService();
        inicializarComponentes();
    }

    private void inicializarComponentes() {
setLayout(new GridLayout(4, 2, 10, 10));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null); // Centrar

        JLabel etiquetaUsuario = new JLabel("Usuario:");
        JLabel etiquetaContrasena = new JLabel("Contraseña:");

        campoUsuario = new JTextField();
        campoContrasena = new JPasswordField();
        botonLogin = new JButton("Iniciar sesión");
        

        botonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String contrasena = new String(campoContrasena.getPassword());

                boolean autenticado = loginService.autenticar(usuario, contrasena);
                if (autenticado) {
                    JOptionPane.showMessageDialog(null, "¡Bienvenido, " + usuario + "!");
                    // Aquí podrías abrir la ventana principal de tu aplicación
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        botonRegistro = new JButton("Registrarse");
botonRegistro.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        new RegistroFrame();
    }
});


        add(etiquetaUsuario);
        add(campoUsuario);
        add(etiquetaContrasena);
        add(campoContrasena);
        add(new JLabel()); // Espacio vacío
        add(botonLogin);
        add(new JLabel("¿No tienes cuenta?"));
add(botonRegistro);


        setVisible(true);
    }
}