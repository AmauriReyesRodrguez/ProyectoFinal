/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import servicio.LoginService;
import modelo.Usuario;
import dao.UsuarioDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class Registro extends javax.swing.JFrame {

      private boolean passwordVisible = false;
    private ImageIcon ojoAbiertoRedimensionado;
    private ImageIcon ojoCerradoRedimensionado;
    
          private boolean passwordVisible2 = false;
    private ImageIcon ojoAbiertoRedimensionado2;
    private ImageIcon ojoCerradoRedimensionado2;
    
     private Color colorOriginalBoton = new Color(255, 51, 51); // Color original del botón
    private Color colorHoverBoton = new Color(200, 51, 51);   // Color al pasar el mouse

    
    public Registro() {
        initComponents();
        inicializarIconosOjo();
        inicializarIconosOjo2();
         agregarEfectoHoverBoton();
         agregarActionListenerBotonRegistrar();
         
    }
    
     private void inicializarIconosOjo() {
        int anchoIcono = 24; // Tamaño deseado del icono
        int altoIcono = 24;

        // Cargar y redimensionar icono de ojo abierto
        ImageIcon ojoAbiertoOriginal = new ImageIcon(getClass().getResource("/imagenes/ojo.png"));
        Image imagenOjoAbierto = ojoAbiertoOriginal.getImage().getScaledInstance(anchoIcono, altoIcono, Image.SCALE_SMOOTH);
        ojoAbiertoRedimensionado = new ImageIcon(imagenOjoAbierto);

        // Cargar y redimensionar icono de ojo cerrado
        ImageIcon ojoCerradoOriginal = new ImageIcon(getClass().getResource("/imagenes/ojoCerrado.png"));
        Image imagenOjoCerrado = ojoCerradoOriginal.getImage().getScaledInstance(anchoIcono, altoIcono, Image.SCALE_SMOOTH);
        ojoCerradoRedimensionado = new ImageIcon(imagenOjoCerrado);

        // Establecer el icono inicial del jLabel (asumiendo que lo llamas ojitoLabel)
        if (ojitoLabel != null) {
            ojitoLabel.setIcon(ojoAbiertoRedimensionado);
        }
    }

        private void inicializarIconosOjo2() {
        int anchoIcono = 24; // Tamaño deseado del icono
        int altoIcono = 24;

        // Cargar y redimensionar icono de ojo abierto
        ImageIcon ojoAbiertoOriginal = new ImageIcon(getClass().getResource("/imagenes/ojo.png"));
        Image imagenOjoAbierto = ojoAbiertoOriginal.getImage().getScaledInstance(anchoIcono, altoIcono, Image.SCALE_SMOOTH);
        ojoAbiertoRedimensionado2 = new ImageIcon(imagenOjoAbierto);

        // Cargar y redimensionar icono de ojo cerrado
        ImageIcon ojoCerradoOriginal = new ImageIcon(getClass().getResource("/imagenes/ojoCerrado.png"));
        Image imagenOjoCerrado = ojoCerradoOriginal.getImage().getScaledInstance(anchoIcono, altoIcono, Image.SCALE_SMOOTH);
        ojoCerradoRedimensionado2 = new ImageIcon(imagenOjoCerrado);

        // Establecer el icono inicial del jLabel (asumiendo que lo llamas ojitoLabel)
        if (ojito2 != null) {
            ojito2.setIcon(ojoAbiertoRedimensionado2);
        }
    }
        
          private void agregarEfectoHoverBoton() {
        botonRegistrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent evt) {
                // Cambiar el color de fondo al pasar el mouse
                botonRegistrar.setBackground(colorHoverBoton);
                botonRegistrar.setContentAreaFilled(true); // Asegurar que se pinte el fondo
            }

            @Override
            public void mouseExited(MouseEvent evt) {
                // Restaurar el color de fondo original al quitar el mouse
                botonRegistrar.setBackground(colorOriginalBoton);
                botonRegistrar.setContentAreaFilled(false); // Volver a la transparencia (si la tenías)
            }
        });
    }
        
          private void agregarActionListenerBotonRegistrar() {
        botonRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                String usuario = campoUsuario.getText();
                String correoElectronico = campoCorreo.getText();
                String contrasena = new String(campoPassword.getPassword());
                String confirmarContrasena = new String(campoPasswordConfi.getPassword());

                if (usuario.isEmpty() || correoElectronico.isEmpty() || contrasena.isEmpty() || confirmarContrasena.isEmpty()) {
                    JOptionPane.showMessageDialog(Registro.this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!contrasena.equals(confirmarContrasena)) {
                    JOptionPane.showMessageDialog(Registro.this, "Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Usuario nuevoUsuario = new Usuario();
                nuevoUsuario.setNombreUsuario(usuario);
                nuevoUsuario.setCorreo(correoElectronico);
                nuevoUsuario.setContrasena(contrasena);

                UsuarioDAO dao = new UsuarioDAO();
                boolean registrado = dao.registrarUsuario(nuevoUsuario);

                if (registrado) {
                    JOptionPane.showMessageDialog(Registro.this, "¡Usuario registrado con éxito!");
                    dispose();
                    // new LoginFrame().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(Registro.this, "Error al registrar el usuario", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelFondo = new javax.swing.JPanel() {
            private Image fondo;
            {
                try {
                    fondo = javax.imageio.ImageIO.read(getClass().getResource("/imagenes/teatro.jpg"));
                } catch (java.io.IOException e) {
                    javax.swing.JOptionPane.showMessageDialog(null, "Error al cargar la imagen de fondo: " + e.getMessage());
                    e.printStackTrace();
                }
            }
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (fondo != null) {
                    g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        panelIzquierdoRegistro = new vista.PanelIzquierdoLogin();
        panelRegistro = new javax.swing.JPanel();
        loginTitulo = new javax.swing.JLabel();
        campoUsuario = new javax.swing.JTextField();
        campoPassword = new javax.swing.JPasswordField();
        botonRegistrar = new javax.swing.JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color( 255,51,51));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                super.paintComponent(g); // Llama al método paintComponent original para dibujar el texto y otros elementos del botón
                g2.dispose();
            }
        };
        iniSesion = new javax.swing.JLabel();
        ojitoLabel = new javax.swing.JLabel();
        campoCorreo = new javax.swing.JTextField();
        campoPasswordConfi = new javax.swing.JPasswordField();
        ojito2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(900, 500));
        getContentPane().setLayout(null);

        panelFondo.setOpaque(false);
        panelFondo.setLayout(null);

        panelIzquierdoRegistro.setOpaque(false);

        javax.swing.GroupLayout panelIzquierdoRegistroLayout = new javax.swing.GroupLayout(panelIzquierdoRegistro);
        panelIzquierdoRegistro.setLayout(panelIzquierdoRegistroLayout);
        panelIzquierdoRegistroLayout.setHorizontalGroup(
            panelIzquierdoRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 520, Short.MAX_VALUE)
        );
        panelIzquierdoRegistroLayout.setVerticalGroup(
            panelIzquierdoRegistroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        panelFondo.add(panelIzquierdoRegistro);
        panelIzquierdoRegistro.setBounds(0, 0, 520, 500);

        panelRegistro.setBackground(new java.awt.Color(30, 30, 30,180));
        panelRegistro.setLayout(null);

        loginTitulo.setFont(new java.awt.Font("Segoe UI", 1, 32)); // NOI18N
        loginTitulo.setForeground(new java.awt.Color(255, 255, 255));
        loginTitulo.setText("Crear Cuenta");
        panelRegistro.add(loginTitulo);
        loginTitulo.setBounds(85, 50, 200, 40);

        campoUsuario.setBackground(new java.awt.Color(242, 242, 242));
        campoUsuario.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        campoUsuario.setBorder(javax.swing.BorderFactory.createTitledBorder("Usuario"));
        campoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoUsuarioActionPerformed(evt);
            }
        });
        panelRegistro.add(campoUsuario);
        campoUsuario.setBounds(75, 100, 220, 40);

        campoPassword.setBackground(new java.awt.Color(242, 242, 242));
        campoPassword.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        campoPassword.setBorder(javax.swing.BorderFactory.createTitledBorder("Contraseña"));
        campoPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoPasswordActionPerformed(evt);
            }
        });
        panelRegistro.add(campoPassword);
        campoPassword.setBounds(75, 200, 220, 40);

        botonRegistrar.setBackground(new java.awt.Color(255, 51, 51));
        botonRegistrar.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        botonRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        botonRegistrar.setText("Registrarse");
        botonRegistrar.setBorderPainted(false);
        botonRegistrar.setContentAreaFilled(false);
        botonRegistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonRegistrar.setFocusPainted(false);
        botonRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistrarActionPerformed(evt);
            }
        });
        panelRegistro.add(botonRegistrar);
        botonRegistrar.setBounds(117, 330, 120, 45);

        iniSesion.setForeground(new java.awt.Color(255, 255, 255));
        iniSesion.setText("<html><a href=''>¿Ya tienes cuenta? <b style='color:#aabaff;'>Inicia Sesión</b></a></html>");
        iniSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        iniSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iniSesionMouseClicked(evt);
            }
        });
        panelRegistro.add(iniSesion);
        iniSesion.setBounds(98, 390, 250, 30);

        ojitoLabel.setMaximumSize(new java.awt.Dimension(30, 28));
        ojitoLabel.setMinimumSize(new java.awt.Dimension(30, 28));
        ojitoLabel.setOpaque(true);
        ojitoLabel.setPreferredSize(new java.awt.Dimension(30, 28));
        ojitoLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ojitoLabelLabelMouseClicked(evt);
            }
        });
        panelRegistro.add(ojitoLabel);
        ojitoLabel.setBounds(296, 200, 30, 40);

        campoCorreo.setBackground(new java.awt.Color(242, 242, 242));
        campoCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        campoCorreo.setBorder(javax.swing.BorderFactory.createTitledBorder("Correo"));
        campoCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoCorreoActionPerformed(evt);
            }
        });
        panelRegistro.add(campoCorreo);
        campoCorreo.setBounds(75, 150, 220, 40);

        campoPasswordConfi.setBackground(new java.awt.Color(242, 242, 242));
        campoPasswordConfi.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        campoPasswordConfi.setBorder(javax.swing.BorderFactory.createTitledBorder("Confirmar Contraseña"));
        campoPasswordConfi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoPasswordConfiActionPerformed(evt);
            }
        });
        panelRegistro.add(campoPasswordConfi);
        campoPasswordConfi.setBounds(75, 250, 220, 40);

        ojito2.setMaximumSize(new java.awt.Dimension(30, 28));
        ojito2.setMinimumSize(new java.awt.Dimension(30, 28));
        ojito2.setOpaque(true);
        ojito2.setPreferredSize(new java.awt.Dimension(30, 28));
        ojito2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ojito2LabelMouseClicked(evt);
            }
        });
        panelRegistro.add(ojito2);
        ojito2.setBounds(296, 250, 30, 40);

        panelFondo.add(panelRegistro);
        panelRegistro.setBounds(520, 0, 380, 500);

        getContentPane().add(panelFondo);
        panelFondo.setBounds(0, 0, 900, 500);
        panelFondo.getAccessibleContext().setAccessibleName("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void campoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoUsuarioActionPerformed

    private void campoPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoPasswordActionPerformed

    private void botonRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistrarActionPerformed
 
    }//GEN-LAST:event_botonRegistrarActionPerformed

    private void iniSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iniSesionMouseClicked
 iniSesion.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mouseClicked(java.awt.event.MouseEvent evt) {
       
        new LoginJFramePrincipal().setVisible(true);
         Registro.this.dispose();
    }
});
    }//GEN-LAST:event_iniSesionMouseClicked

    private void ojitoLabelLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ojitoLabelLabelMouseClicked
passwordVisible = !passwordVisible;
        if (passwordVisible) {
            campoPassword.setEchoChar((char) 0); // Mostrar contraseña
            ojitoLabel.setIcon(ojoCerradoRedimensionado);
        } else {
            campoPassword.setEchoChar('*'); // Ocultar contraseña
            ojitoLabel.setIcon(ojoAbiertoRedimensionado);
        }
// TODO add your handling code here:
    }//GEN-LAST:event_ojitoLabelLabelMouseClicked

    private void campoCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoCorreoActionPerformed

    private void campoPasswordConfiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoPasswordConfiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoPasswordConfiActionPerformed

    private void ojito2LabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ojito2LabelMouseClicked
passwordVisible2 = !passwordVisible2;
        if (passwordVisible2) {
            campoPasswordConfi.setEchoChar((char) 0); // Mostrar contraseña
            ojito2.setIcon(ojoCerradoRedimensionado2);
        } else {
            campoPasswordConfi.setEchoChar('*'); // Ocultar contraseña
            ojito2.setIcon(ojoAbiertoRedimensionado2);
        }
    }//GEN-LAST:event_ojito2LabelMouseClicked

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonRegistrar;
    private javax.swing.JTextField campoCorreo;
    private javax.swing.JPasswordField campoPassword;
    private javax.swing.JPasswordField campoPasswordConfi;
    private javax.swing.JTextField campoUsuario;
    private javax.swing.JLabel iniSesion;
    private javax.swing.JLabel loginTitulo;
    private javax.swing.JLabel ojito2;
    private javax.swing.JLabel ojitoLabel;
    private javax.swing.JPanel panelFondo;
    private vista.PanelIzquierdoLogin panelIzquierdoRegistro;
    private javax.swing.JPanel panelRegistro;
    // End of variables declaration//GEN-END:variables
}
