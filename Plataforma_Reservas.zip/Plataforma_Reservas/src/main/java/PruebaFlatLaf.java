import javax.swing.*;
import com.formdev.flatlaf.FlatLightLaf;

public class PruebaFlatLaf {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }

        JFrame frame = new JFrame("Prueba FlatLaf");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLayout(new java.awt.FlowLayout());

        JButton boton1 = new JButton("Botón 1");
        JButton boton2 = new JButton("Otro Botón");
        JTextField textField = new JTextField(15);
        JLabel label = new JLabel("Esto es una etiqueta:");

        frame.add(label);
        frame.add(textField);
        frame.add(boton1);
        frame.add(boton2);

        frame.setVisible(true);
    }
}