package swing;

import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class Utilidades {
    public static Border crearBordeRedondeado(int padding, int grosorBorde, Color colorBorde, int radioEsquinas) {
        Border empty = new EmptyBorder(padding, padding, padding, padding);
        Border redondeado = new LineBorder(colorBorde, grosorBorde, true); // true = esquinas redondeadas
        return new CompoundBorder(redondeado, empty);
    }
}
