package menuSala;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class PanelAñadirSala extends JPanel {

    private boolean isHover = false;

    public PanelAñadirSala() {
        setPreferredSize(new Dimension(150, 150)); // Tamaño inicial, puedes ajustarlo
        setBackground(new Color(240, 240, 240)); // Un gris claro de fondo
        setBorder(new EmptyBorder(10, 10, 10, 10)); // Margen interno
        setLayout(new java.awt.BorderLayout());
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR)); // Cambiar el cursor al pasar por encima

        JLabel labelSignoMas = new JLabel("+");
        labelSignoMas.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        labelSignoMas.setForeground(Color.GRAY);
        labelSignoMas.setHorizontalAlignment(SwingConstants.CENTER);
        add(labelSignoMas, java.awt.BorderLayout.CENTER);

        JLabel labelAñadir = new JLabel("Añadir Sala");
        labelAñadir.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        labelAñadir.setForeground(Color.GRAY);
        labelAñadir.setHorizontalAlignment(SwingConstants.CENTER);
        add(labelAñadir, java.awt.BorderLayout.SOUTH);

        addMouseListener(new MouseAdapter() {
    private Color originalBackground;
    private Color clickColor = new Color(190, 190, 190, 100); // Un gris semitransparente similar al hover de los botones

    @Override
    public void mouseEntered(MouseEvent e) {
        isHover = true;
        repaint();
    }

    @Override
    public void mouseExited(MouseEvent e) {
        isHover = false;
        repaint();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        originalBackground = getBackground();
        setBackground(clickColor);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        setBackground(originalBackground);
        System.out.println("Panel Añadir Sala clickeado!");
        // Implementa aquí la acción al hacer clic
    }
});
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();
        int arc = 20; // Radio para las esquinas redondeadas

        // Dibujar el fondo con esquinas redondeadas
        g2d.setColor(getBackground());
        g2d.fillRoundRect(0, 0, width, height, arc, arc);

        // Dibujar un efecto de "hover" sutil
        if (isHover) {
            g2d.setColor(new Color(220, 220, 220)); // Un gris ligeramente más oscuro
            g2d.fillRoundRect(0, 0, width, height, arc, arc);
        }

        // Dibujar el signo más y el texto (asegurándonos de que sean legibles sobre el hover)
        g2d.setColor(Color.GRAY);
        g2d.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        int plusWidth = g2d.getFontMetrics().stringWidth("+");

        FontMetrics fm = g2d.getFontMetrics(new Font("Segoe UI", Font.PLAIN, 40));
int ascent = fm.getAscent();
int descent = fm.getDescent();
int y = (height - (ascent + descent)) / 2 + ascent;
g2d.drawString("+", (width - plusWidth) / 2, y);
        
        g2d.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        int añadirWidth = g2d.getFontMetrics().stringWidth("Añadir Sala");
        g2d.drawString("Añadir Sala", (width - añadirWidth) / 2, height - 20);

        g2d.dispose();
    }
}