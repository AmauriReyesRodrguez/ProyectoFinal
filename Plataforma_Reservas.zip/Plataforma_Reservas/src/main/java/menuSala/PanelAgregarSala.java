package menuSala;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelAgregarSala extends JPanel {

    private JLabel iconoMas;
    private JLabel texto;

    public PanelAgregarSala(Runnable onClick) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setPreferredSize(new Dimension(250, 250));
        setBackground(Color.LIGHT_GRAY);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setBorder(BorderFactory.createLineBorder(Color.GRAY));

        iconoMas = new JLabel("+", SwingConstants.CENTER);
        iconoMas.setFont(new Font("Arial", Font.BOLD, 48));
        iconoMas.setAlignmentX(Component.CENTER_ALIGNMENT);

        texto = new JLabel("Añadir sala", SwingConstants.CENTER);
        texto.setFont(new Font("Arial", Font.PLAIN, 14));
        texto.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createVerticalGlue());
        add(iconoMas);
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(texto);
        add(Box.createVerticalGlue());

        // Cambios de color en hover
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(new Color(200, 200, 200));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setBackground(Color.LIGHT_GRAY);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                setBackground(new Color(160, 160, 160));
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                setBackground(new Color(200, 200, 200));
                onClick.run();
            }
        });
    }
}
