package modelo_Test;

import java.util.List;
import javax.swing.ImageIcon;

public class Sala {
    private String nombre;
    private int capacidad;
    private List<ImageIcon> imagenes;

        // Puedes agregar luego imagen, componentes, estado, etc.

    
    public Sala(String nombre, int capacidad, List<ImageIcon> imagenes) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.imagenes = imagenes;
    }

    // Getters
    public String getNombre() { return nombre; }
    public int getCapacidad() { return capacidad; }
    public List<ImageIcon> getImagenes() { return imagenes; }
}
