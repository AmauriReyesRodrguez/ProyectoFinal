
package servicio_Test;

import dao_Test.UsuarioDAO;
import modelo_Test.Usuario;

public class LoginService {
    
    private UsuarioDAO usuarioDAO;

    public LoginService() {
        this.usuarioDAO = new UsuarioDAO();
    }

    public boolean autenticar(String nombreUsuario, String contrasena) {
        Usuario usuario = usuarioDAO.obtenerUsuarioPorNombre(nombreUsuario);
        
        if (usuario != null && usuario.getContrasena().equals(contrasena)) {
            return true;
        } else {
            return false;
        }
    }
}