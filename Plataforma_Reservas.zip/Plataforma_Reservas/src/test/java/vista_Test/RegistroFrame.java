package vista_Test;

import javax.swing.*;
import modelo_Test.Usuario;
import dao_Test.UsuarioDAO;
import java.awt.*;
import java.awt.event.*;

public class RegistroFrame extends JFrame {

    private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JButton botonRegistrar;

    public RegistroFrame() {
        super("Registro de Usuario");
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        setLayout(new GridLayout(3, 2, 10, 10));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null);

        JLabel etiquetaUsuario = new JLabel("Nuevo usuario:");
        JLabel etiquetaContrasena = new JLabel("Contraseña:");

        campoUsuario = new JTextField();
        campoContrasena = new JPasswordField();
        botonRegistrar = new JButton("Registrar");

        botonRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String contrasena = new String(campoContrasena.getPassword());

                Usuario nuevoUsuario = new Usuario();
                nuevoUsuario.setNombreUsuario(usuario);
                nuevoUsuario.setContrasena(contrasena);

                UsuarioDAO dao = new UsuarioDAO();
                boolean registrado = dao.registrarUsuario(nuevoUsuario);

                if (registrado) {
                    JOptionPane.showMessageDialog(null, "¡Usuario registrado con éxito!");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(etiquetaUsuario);
        add(campoUsuario);
        add(etiquetaContrasena);
        add(campoContrasena);
        add(new JLabel());
        add(botonRegistrar);

        setVisible(true);
    }
}
