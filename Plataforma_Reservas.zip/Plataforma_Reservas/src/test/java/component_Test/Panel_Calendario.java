package component_Test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class Panel_Calendario extends javax.swing.JPanel {

    private JLabel lblMes;
    private JPanel panelDias;
    private LocalDate fechaActual;

    public Panel_Calendario() {
        fechaActual = LocalDate.now();
        initComponents();
        mostrarCalendario(fechaActual);
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Parte superior con el nombre del mes y flechas
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton btnAnterior = new JButton("<");
        JButton btnSiguiente = new JButton(">");
        lblMes = new JLabel();
        lblMes.setFont(new Font("SansSerif", Font.BOLD, 20));

        btnAnterior.addActionListener(e -> cambiarMes(-1));
        btnSiguiente.addActionListener(e -> cambiarMes(1));

        panelSuperior.add(btnAnterior);
        panelSuperior.add(lblMes);
        panelSuperior.add(btnSiguiente);
        add(panelSuperior, BorderLayout.NORTH);

        // Panel central para los días
        panelDias = new JPanel(new GridLayout(0, 7, 5, 5));
        panelDias.setBorder(new EmptyBorder(10, 10, 10, 10));
        add(panelDias, BorderLayout.CENTER);

        // Panel lateral derecho
        JPanel panelLateral = new JPanel();
        panelLateral.setPreferredSize(new Dimension(200, 0));
        panelLateral.setLayout(new BorderLayout());
        JLabel lblNavegador = new JLabel("Navegador de reservas", SwingConstants.CENTER);
        lblNavegador.setFont(new Font("SansSerif", Font.BOLD, 16));
        panelLateral.add(lblNavegador, BorderLayout.NORTH);

        add(panelLateral, BorderLayout.EAST);
    }

    private void mostrarCalendario(LocalDate fecha) {
        panelDias.removeAll();
        lblMes.setText(fecha.getMonth().getDisplayName(TextStyle.FULL, new Locale("es", "ES")) + " " + fecha.getYear());

        LocalDate primerDia = fecha.withDayOfMonth(1);
        int diaSemana = primerDia.getDayOfWeek().getValue();
        int diasDelMes = fecha.lengthOfMonth();

        for (int i = 1; i < diaSemana; i++) {
            panelDias.add(new JLabel(""));
        }

        for (int dia = 1; dia <= diasDelMes; dia++) {
            JButton btnDia = new JButton(String.valueOf(dia));
            btnDia.setFocusPainted(false);
            btnDia.setBorder(BorderFactory.createEmptyBorder());
            btnDia.setBackground(Color.WHITE);
            btnDia.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btnDia.setContentAreaFilled(true);
            btnDia.setOpaque(true);

            btnDia.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    btnDia.setBackground(new Color(220, 220, 220)); // Hover
                }
                public void mouseExited(MouseEvent e) {
                    btnDia.setBackground(Color.WHITE);
                }
                public void mousePressed(MouseEvent e) {
                    btnDia.setBackground(new Color(150, 200, 255)); // Selección
                }
            });

            panelDias.add(btnDia);
        }

        panelDias.revalidate();
        panelDias.repaint();
    }

    private void cambiarMes(int cambio) {
        fechaActual = fechaActual.plusMonths(cambio);
        mostrarCalendario(fechaActual);
    }
}
