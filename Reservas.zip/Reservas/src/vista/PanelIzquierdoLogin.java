/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

/**
 *
 * @author Antonio Reyes
 */
public class PanelIzquierdoLogin extends javax.swing.JPanel {

    /**
     * Creates new form PanelIzquierdoLogin
     */
    public PanelIzquierdoLogin() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setFont(new Font("Georgia", Font.BOLD, 34));
        g2d.setColor(Color.WHITE);
        g2d.drawString("Bienvenido a", 100, 150);
        g2d.setColor(new Color(248, 116, 116));
        g2d.setFont(new Font("Georgia", Font.BOLD, 40));
        g2d.drawString("BROOK JAAF", 100, 200);
        g2d.setFont(new Font("Segoe UI", Font.ITALIC, 18));
        g2d.setColor(new Color(220, 220, 220));
        g2d.drawString("Sumérgete en una experiencia teatral única...", 100, 250);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
