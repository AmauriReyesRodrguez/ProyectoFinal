/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//package Principal;
//
//import ConexionDB.ConexionDB;
//import java.sql.Connection;
//
//public class Principal {
//    public static void main(String[] args) {
//        Connection conn = ConexionDB.conectar();
//        if (conn != null) {
//            System.out.println("Prueba exitosa ✔");
//        } else {
//            System.out.println("Prueba fallida ❌");
//        }
//    }
//}

