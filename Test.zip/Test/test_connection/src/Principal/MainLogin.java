package principal;

import servicio.LoginService;
import java.util.Scanner;

public class MainLogin {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LoginService loginService = new LoginService();

        System.out.println("===== LOGIN DE PRUEBA =====");
        System.out.print("Correo: ");
        String email = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contraseña = scanner.nextLine();

        loginService.login(email, contraseña);
    }
}
