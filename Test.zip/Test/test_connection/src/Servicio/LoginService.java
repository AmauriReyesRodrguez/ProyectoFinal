package servicio;

import dao.UsuarioDAO;
import modelo.Usuario;

public class LoginService {
    private UsuarioDAO usuarioDAO;

    public LoginService() {
        this.usuarioDAO = new UsuarioDAO();
    }

    public boolean login(String email, String contraseña) {
        Usuario usuario = usuarioDAO.obtenerPorEmailYContraseña(email, contraseña);
        if (usuario != null) {
            System.out.println("✔ Bienvenido, " + usuario.getNombre() + "!");
            return true;
        } else {
            System.out.println("❌ Usuario o contraseña incorrectos.");
            return false;
        }
    }
}
